//
//  ListViewController.swift
//  OnTheMap
//
//  Created by Ameera AlHassan on 7/9/20.
//  Copyright © 2020 Udacity. All rights reserved.
//

import UIKit

class TableViewController: ContainerViewController {
    
    let tableCell = "tableViewCell"
    
    @IBOutlet weak var tableView: UITableView!
    
    override var locationsData: LocationsData? {
        didSet {
            guard let locationsData = locationsData else { return }
            locationsInfo = locationsData.results
        }
    }
    
    var locationsInfo: [StudentLocation] = [] {
        didSet {
            tableView.reloadData()
        }
    }
    
    @IBAction private func addLocationPressed(_ sender: Any) {
        let navigationController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AddLocationNavController") as! UINavigationController
        
        present(navigationController, animated: true, completion: nil)
    }
    
    @IBAction private func refreshLocationsPressed(_ sender: Any) {
        loadStudentLocations()
    }
    
    @IBAction private func logoutPressed(_ sender: Any) {
        let alert = UIAlertController(title: "Logout", message: "Are you sure you want to logout?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Logout", style: .destructive, handler: { (_) in UdacityAPI.deleteSession { (err) in guard err == nil else {
            self.showAlert(title: "Error", message: err!)
            return
            }
            self.dismiss(animated: true, completion: nil)
            }}))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        present(alert, animated: true, completion: nil)
        
    }
}

extension TableViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return locationsInfo.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: tableCell) as! TableViewCell

        cell.nameLabel?.text = locationsInfo[indexPath.row].firstName
        cell.urlLabel?.text = locationsInfo[indexPath.row].mediaURL
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath,animated: true)

        UIApplication.shared.open(URL(string: locationsInfo[indexPath.row].mediaURL!)!, options: [:], completionHandler: nil)
    }

}
