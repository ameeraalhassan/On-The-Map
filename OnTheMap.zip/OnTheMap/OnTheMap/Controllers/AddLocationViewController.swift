//
//  Add.swift
//  OnTheMap
//
//  Created by Ameera AlHassan on 7/25/20.
//  Copyright © 2020 Udacity. All rights reserved.
//

import Foundation
import UIKit
import CoreLocation
import MapKit

class AddLocationViewController: UIViewController {
    
    @IBOutlet weak var locationTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupUI()
    }
    
    @IBAction func findLocation(_ sender: Any) {
        guard let location = locationTextField.text,
            location != "" else {
                self.showAlert(title: "Missing Information", message: "Please fill the location field and try again")
                return
        }
        let studentLocation = StudentLocation(mapString: location, mediaURL: "")
        geocodeCoordinates(studentLocation)
    }
    
    private func geocodeCoordinates(_ studentLocation: StudentLocation) {
        
        let ai = self.startAnActivityIndicator()
        
        CLGeocoder().geocodeAddressString(studentLocation.mapString!) { (placeMarks, err) in
            
            ai.stopAnimating()
            
            guard let firstLocation = placeMarks?.first?.location else {
                self.showAlert(title: "Error", message: "Geocoding failed")
                return
                
            }
            
            var location = studentLocation
            location.latitude = firstLocation.coordinate.latitude
            location.longitude = firstLocation.coordinate.longitude
            
            self.performSegue(withIdentifier: "locationSegue", sender: location)
            
        }
        
    }
    
      private func setupUI() {
        locationTextField.delegate = self
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "locationSegue", let viewController = segue.destination as? ConfirmLocationViewController {
            viewController.location = (sender as! StudentLocation)
        }
    }
    
    @IBAction private func cancelPressed(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    
}
