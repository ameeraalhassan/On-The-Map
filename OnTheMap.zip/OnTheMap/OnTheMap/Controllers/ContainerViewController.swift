//
//  ContainerViewController.swift
//  OnTheMap
//
//  Created by Ameera AlHassan on 7/16/20.
//  Copyright © 2020 Udacity. All rights reserved.
//

import Foundation
import UIKit

class ContainerViewController: UIViewController {
    
    var locationsData: LocationsData?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        loadStudentLocations()
    }
    
    func loadStudentLocations() {
        let ai = startAnActivityIndicator()
        ParseAPI.getStudentLocations { (data) in
            ai.stopAnimating()
            guard let data = data else {
                self.showAlert(title: "Error", message: "No internet connection found")
                return
            }
            guard data.results.count > 0 else {
                self.showAlert(title: "Error", message: "No pins found")
                return
            }
            self.locationsData = data
        }
    }
    
}
