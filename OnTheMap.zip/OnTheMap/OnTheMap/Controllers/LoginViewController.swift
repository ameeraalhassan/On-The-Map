//
//  ViewController.swift
//  OnTheMap
//
//  Created by Ameera AlHassan on 7/9/20.
//  Copyright © 2020 Udacity. All rights reserved.
//

import UIKit
import Foundation

class LoginViewController: UIViewController {

    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var signupButton: UIButton!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        emailTextField.text = ""
        passwordTextField.text = ""
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUpUI()
    }
    
    private func setUpUI(){
        emailTextField.delegate = self
        passwordTextField.delegate = self
    }
    
    @IBAction func loginPressed(_ sender: Any) {
        UdacityAPI.postSession(username: emailTextField.text!, password: passwordTextField.text!){ data, error in
            DispatchQueue.main.async {
                if error != nil {
                    self.showAlert(title: "Error", message: "Login Failed!")
                    return
                } else {
                    self.performSegue(withIdentifier: "loginSegue", sender: nil)
                }
            }
    }
    }
    
    @IBAction func signupPressed(_ sender: Any) {
        if let url = URL(string: "https://www.udacity.com/account/auth#!/signup"),
            UIApplication.shared.canOpenURL(url) {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
    }
    

}
