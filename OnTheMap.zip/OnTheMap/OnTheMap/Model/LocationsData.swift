//
//  LocationsData.swift
//  OnTheMap
//
//  Created by Ameera AlHassan on 7/16/20.
//  Copyright © 2020 Udacity. All rights reserved.
//

import Foundation

struct LocationsData: Codable {
    var results: [StudentLocation] = []
}
