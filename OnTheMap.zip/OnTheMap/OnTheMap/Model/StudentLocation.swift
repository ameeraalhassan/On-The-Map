//
//  StudentLocation.swift
//  OnTheMap
//
//  Created by Ameera AlHassan on 7/9/20.
//  Copyright © 2020 Udacity. All rights reserved.
//

import Foundation

struct StudentLocation: Codable {
    var objectId: String?
    var uniqueKey: String?
    var firstName: String?
    var lastName: String?
    var mapString: String?
    var mediaURL: String?
    var latitude: Double?
    var longitude: Double?
    var createdAt: String?
    var updatedAt: String?
}

extension StudentLocation {
    init(mapString: String, mediaURL: String){
        self.mapString = mapString
        self.mediaURL = mediaURL

    }
}

