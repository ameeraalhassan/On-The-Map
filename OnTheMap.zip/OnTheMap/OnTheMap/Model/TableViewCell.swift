//
//  TableViewCell.swift
//  OnTheMap
//
//  Created by Ameera AlHassan on 7/27/20.
//  Copyright © 2020 Udacity. All rights reserved.
//

import Foundation
import UIKit

class TableViewCell: UITableViewCell {
    
    @IBOutlet weak var urlLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
