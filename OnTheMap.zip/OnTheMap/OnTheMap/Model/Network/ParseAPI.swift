//
//  API.swift
//  OnTheMap
//
//  Created by Ameera AlHassan on 7/16/20.
//  Copyright © 2020 Udacity. All rights reserved.
//

import Foundation

class ParseAPI {
    
    static var userInfo = UserInfo()
    
    static func getStudentLocations(completion: @escaping (LocationsData?)->Void) {

        var request = URLRequest(url: URL(string: "https://onthemap-api.udacity.com/v1/StudentLocation?limit=100&&skip=400order=-updatedAt")!)
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            var locationInfo: LocationsData?
            if let statusCode = (response as? HTTPURLResponse)?.statusCode {
                if statusCode >= 200 && statusCode < 300 {
                    
                    do {
                        locationInfo = try JSONDecoder().decode(LocationsData.self, from: data!)
                        
                    } catch {
                        debugPrint(error)
                    }
                }
            }
            DispatchQueue.main.async {
                completion(locationInfo)
            }
        }
        task.resume()
        }
    
    static func postLocation(_ location: StudentLocation, completion: @escaping (String?)->Void) {
        
        var request = URLRequest(url: URL(string: "https://onthemap-api.udacity.com/v1/StudentLocation")!)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = "{\"uniqueKey\": \"\(userInfo.key ?? ".."))\", \"firstName\": \"\(userInfo.firstName ?? "..")\", \"lastName\": \"\(userInfo.lastName ?? "..")\", \"mapString\": \"\(location.mapString ?? "0")\", \"mediaURL\": \"\(location.mediaURL ?? "..")\", \"latitude\": \(location.latitude ?? 1), \"longitude\": \(location.longitude ?? 1)}".data(using: String.Encoding.utf8)
        
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            
            if let statusCode = (response as? HTTPURLResponse)?.statusCode {
                if statusCode >= 400 {
                     print(error)
                    return
                }
            }
            print(String(data: data!, encoding: .utf8)!)
           
        }
        task.resume()
        }
        
        static func updateStudentLocation(_ location: StudentLocation,completion: @escaping (Error?)-> Void){

            var request = URLRequest(url: URL(string: "https://onthemap-api.udacity.com/v1/StudentLocation/\(location.objectId)")!)
            request.httpMethod = "PUT"
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = "{\"uniqueKey\": \"\(userInfo.key ?? ".."))\", \"firstName\": \"\(userInfo.firstName ?? "..")\", \"lastName\": \"\(userInfo.lastName ?? "..")\", \"mapString\": \"\(location.mapString ?? "0")\", \"mediaURL\": \"\(location.mediaURL ?? "..")\", \"latitude\": \(location.latitude ?? 1), \"longitude\": \(location.longitude ?? 1)}".data(using: String.Encoding.utf8)
            
            let session = URLSession.shared
            let task = session.dataTask(with: request) { data, response, error in
                if error != nil {
                    return
                }
                print(String(data: data!, encoding: .utf8)!)
            }
            task.resume()
        }
        
}
