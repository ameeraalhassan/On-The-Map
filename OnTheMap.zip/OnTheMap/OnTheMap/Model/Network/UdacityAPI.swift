//
//  UdacityAPI.swift
//  OnTheMap
//
//  Created by Ameera AlHassan on 7/27/20.
//  Copyright © 2020 Udacity. All rights reserved.
//

import Foundation

class UdacityAPI: ParseAPI {
    
    private static var sessionId: String?
    
    static func postSession(username: String, password: String, completion: @escaping (Data?, Error?)->Void) {
        
        var request = URLRequest(url: URL(string: "https://onthemap-api.udacity.com/v1/session")!)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = "{\"udacity\": {\"username\": \"\(username)\", \"password\": \"\(password)\"}}".data(using: .utf8)
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            
                if error != nil {
                    completion(nil, error)
                    return
                }
            
            if let statusCode = (response as? HTTPURLResponse)?.statusCode, statusCode < 400 {
                
                let range = (5..<data!.count)
                let newData = data?.subdata(in: range)
                print(String(data: newData!, encoding: .utf8)!)
                completion(newData, nil)

            } else {
                completion(nil, NSError(domain: "URLError", code: 0, userInfo: nil))
            }
        }
        task.resume()
    }
    
    static func deleteSession(completion: @escaping (String?)-> Void){
        
        var request = URLRequest(url: URL(string: "https://onthemap-api.udacity.com/v1/session")!)
        var xsrfCookie: HTTPCookie? = nil
        let shareCookieStorage = HTTPCookieStorage.shared
        for cookie in shareCookieStorage.cookies! {
            if cookie.name == "XSRF-TOKEN" { xsrfCookie = cookie }
        }
        if let xsrfCookie = xsrfCookie {
            request.setValue(xsrfCookie.value, forHTTPHeaderField: "X-XSRF-TOKEN")
        }
        let session = URLSession.shared
        let task = session.dataTask(with: request){ data, response, error in
            if error != nil {
                return
            }
            if (data?.count ?? 0) > 5, let newData = data?.subdata(in: 5..<data!.count){
                print(String(data: newData, encoding: .utf8)!)
            }
            DispatchQueue.main.async {
                completion(nil)
            }
            
        }
        task.resume()
    }
    
    static func getUserInfo(completion: @escaping (Error?)-> Void){
        
        var request = URLRequest(url: URL(string: "https://onthemap-api.udacity.com/v1/users/(userInfo.key!)")!)
        request.addValue(self.sessionId!, forHTTPHeaderField: "session_id")
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            var firstName: String?, lastName: String?, nickname: String = ""
            if let statusCode = (response as? HTTPURLResponse)?.statusCode, statusCode < 400 {
                let newData = data?.subdata(in: 5..<data!.count)
                if let json = try? JSONSerialization.jsonObject(with: newData!, options: []),
                    let dict = json as? [String: Any] {
                    
                    nickname = dict["nickname"] as? String ?? ""
                    firstName = dict["first_name"] as? String ?? nickname
                    lastName = dict["last_name"] as? String ?? nickname
                    
                    userInfo.firstName = firstName
                    userInfo.lastName = lastName
                    
                    self.getUserInfo(completion: { err in })
                }
            }
            DispatchQueue.main.async {
                completion(nil)
            }
        }
        task.resume()
    }

}
